﻿// laploy course C# programming language

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00342_Interface
{
    // this is architect core level code
    public interface ILogAble
    {
        void WriteLog();
    }

    // thi is mid level code
    public class Foo: ILogAble
    {
        public void WriteLog()
        {
            Console.WriteLine("Foo was logged");
        }
    }
    public class Bar : ILogAble
    {
        public void WriteLog()
        {
            Console.WriteLine("Bar was logged");
        }
    }

    // this is utility service code
    public class Log
    {
        public static void LogNow(ILogAble logObj)
        {
            logObj.WriteLog();
        }
    }

    // this is end-user level code
    class Program
    {
        static void Main(string[] args)
        {
            Foo myFoo = new Foo();
            Bar myBar = new Bar();
            Log.LogNow(myFoo);
            Log.LogNow(myBar);
        }
    }
}
